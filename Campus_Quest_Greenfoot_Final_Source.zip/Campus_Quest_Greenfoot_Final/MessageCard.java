import greenfoot.*;

/** Tarjeta de texto para instrucciones o mensajes finales. */
public class MessageCard extends Actor {
    public MessageCard(String text) {
        String[] lines = text.split("\\n");
        int width = 520;
        int height = Math.max(80, 36 + lines.length * 26);
        GreenfootImage img = new GreenfootImage(width, height);
        img.setColor(new Color(0, 0, 0, 145));
        img.fillRoundRect(0, 0, width, height, 18, 18);
        img.setColor(Color.WHITE);
        for (int i = 0; i < lines.length; i++) {
            img.drawString(lines[i], 18, 28 + i * 24);
        }
        setImage(img);
    }
}
