import greenfoot.*;

/** Obstaculo: representa estres y distracciones. */
public class StressCloud extends Actor {
    private int speed;

    public StressCloud(int level) {
        speed = 2 + level;
        GreenfootImage img = new GreenfootImage(54, 36);
        img.setColor(new Color(95, 95, 115));
        img.fillOval(2, 12, 24, 18);
        img.fillOval(15, 6, 24, 24);
        img.fillOval(30, 12, 22, 18);
        img.setColor(Color.WHITE);
        img.drawString("!", 25, 25);
        setImage(img);
    }

    public void act() {
        setLocation(getX(), getY() + speed);
        if (getWorld() != null && getY() > getWorld().getHeight() + 20) {
            getWorld().removeObject(this);
        }
    }
}
