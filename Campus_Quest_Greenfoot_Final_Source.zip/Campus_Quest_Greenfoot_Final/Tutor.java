import greenfoot.*;

/** Apoyo academico que baja el estres. */
public class Tutor extends Actor {
    public Tutor() {
        GreenfootImage img = new GreenfootImage(44, 44);
        img.setColor(new Color(105, 220, 160));
        img.fillOval(4, 4, 36, 36);
        img.setColor(new Color(25, 80, 60));
        img.drawOval(4, 4, 36, 36);
        img.drawString("?", 17, 29);
        setImage(img);
    }
}
