# Campus Quest

Proyecto final del juego desarrollado en Greenfoot para Introduccion a la Ingenieria.

## Integrantes
- John Lizama
- Santiago Martinez

## Idea del juego
Campus Quest es un juego casual de avance academico. El jugador controla a un estudiante dentro del campus y debe recolectar entregas, cafe y apoyo de tutores mientras evita nubes de estres. El objetivo es llegar al portal de salida con suficientes puntos y completar tres niveles.

## Controles
- Flechas o WASD: mover al estudiante.
- ENTER: reiniciar al terminar la partida.

## Elementos principales
- Entregas: dan puntos y reducen un poco el estres.
- Cafe: aumenta temporalmente la velocidad.
- Tutor: reduce el estres de forma importante.
- Nube de estres: quita vida y aumenta el estres.
- Portal: permite pasar de nivel si se tiene el puntaje minimo.

## Clases del proyecto
- CampusQuestWorld.java: mundo principal, puntaje, vidas, niveles, tiempo y reglas.
- Student.java: movimiento del jugador y colisiones.
- Assignment.java: objeto recolectable de puntaje.
- Coffee.java: objeto de velocidad temporal.
- Tutor.java: objeto de apoyo academico.
- StressCloud.java: obstaculo del juego.
- GoalPortal.java: cambio de nivel o victoria.
- MessageCard.java: mensajes de instrucciones y final.

## Cambios aplicados despues de la validacion
- Se agregaron instrucciones visibles al inicio.
- Se agregaron niveles de dificultad.
- Se incluyo un sistema de estres para que el juego no fuera solo de recolectar objetos.
- Se agregaron objetos de apoyo para que el jugador pueda recuperarse.
- Se mejoro la claridad del HUD con puntos, estres, vidas, nivel y tiempo.

## Repositorio sugerido
https://github.com/pslizama98-source/campus-quest-greenfoot
