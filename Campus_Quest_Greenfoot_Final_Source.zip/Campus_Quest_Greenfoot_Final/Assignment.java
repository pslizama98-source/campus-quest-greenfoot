import greenfoot.*;

/** Entrega o tarea que aumenta el punteo. */
public class Assignment extends Actor {
    public Assignment() {
        GreenfootImage img = new GreenfootImage(38, 42);
        img.setColor(new Color(250, 250, 240));
        img.fillRect(6, 4, 26, 34);
        img.setColor(new Color(55, 90, 140));
        img.drawRect(6, 4, 26, 34);
        img.drawLine(10, 14, 27, 14);
        img.drawLine(10, 21, 27, 21);
        img.drawLine(10, 28, 23, 28);
        setImage(img);
    }
}
