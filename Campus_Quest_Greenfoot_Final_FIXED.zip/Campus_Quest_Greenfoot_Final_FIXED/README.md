# Campus Quest

Proyecto final del juego desarrollado en Greenfoot para Introduccion a la Ingenieria.

## Integrantes
- John Lizama
- Santiago Martinez

## Controles
- Flechas o WASD: mover al estudiante.
- ENTER: reiniciar al terminar la partida.

## Objetivo
Recolectar entregas, manejar el estres y llegar al portal final. El juego tiene puntos, vidas, estres, tiempo y tres niveles.
