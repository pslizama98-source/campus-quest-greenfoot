import greenfoot.*;

/** Personaje controlado por el jugador. */
public class Student extends Actor
{
    private int speed = 4;
    private int boostTimer = 0;

    public Student()
    {
        drawImage();
    }

    public void act()
    {
        moveWithKeyboard();
        checkCollisions();

        if (boostTimer > 0) {
            boostTimer--;
            if (boostTimer == 0) {
                speed = 4;
                drawImage();
            }
        }
    }

    private void moveWithKeyboard()
    {
        int dx = 0;
        int dy = 0;

        if (Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")) dx += speed;
        if (Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a")) dx -= speed;
        if (Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w")) dy -= speed;
        if (Greenfoot.isKeyDown("down") || Greenfoot.isKeyDown("s")) dy += speed;

        int newX = Math.max(20, Math.min(getWorld().getWidth() - 20, getX() + dx));
        int newY = Math.max(55, Math.min(getWorld().getHeight() - 20, getY() + dy));
        setLocation(newX, newY);
    }

    private void checkCollisions()
    {
        CampusQuestWorld world = (CampusQuestWorld)getWorld();

        Assignment assignment = (Assignment)getOneIntersectingObject(Assignment.class);
        if (assignment != null) world.collectAssignment(assignment);

        Coffee coffee = (Coffee)getOneIntersectingObject(Coffee.class);
        if (coffee != null) world.collectCoffee(coffee);

        Tutor tutor = (Tutor)getOneIntersectingObject(Tutor.class);
        if (tutor != null) world.collectTutor(tutor);

        StressCloud cloud = (StressCloud)getOneIntersectingObject(StressCloud.class);
        if (cloud != null) world.hitStress(cloud);

        GoalPortal portal = (GoalPortal)getOneIntersectingObject(GoalPortal.class);
        if (portal != null) world.enterPortal();
    }

    public void boostSpeed()
    {
        speed = 6;
        boostTimer = 210;
        drawImage();
    }

    private void drawImage()
    {
        GreenfootImage img = new GreenfootImage(44, 54);
        img.setColor(new Color(245, 210, 150));
        img.fillOval(13, 2, 18, 18);

        if (boostTimer > 0) {
            img.setColor(new Color(255, 210, 65));
        } else {
            img.setColor(new Color(63, 137, 205));
        }

        img.fillRoundRect(9, 20, 26, 28, 8, 8);
        img.setColor(new Color(30, 35, 45));
        img.fillRect(13, 46, 7, 8);
        img.fillRect(25, 46, 7, 8);
        img.setColor(Color.WHITE);
        img.drawString("J", 19, 38);
        setImage(img);
    }
}
