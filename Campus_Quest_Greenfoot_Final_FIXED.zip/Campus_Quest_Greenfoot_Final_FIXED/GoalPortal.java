import greenfoot.*;

/** Portal para pasar de nivel. */
public class GoalPortal extends Actor
{
    public GoalPortal()
    {
        GreenfootImage img = new GreenfootImage(66, 84);
        img.setColor(new Color(120, 95, 210));
        img.fillOval(9, 4, 48, 76);
        img.setColor(new Color(245, 225, 90));
        img.drawOval(9, 4, 48, 76);
        img.drawString("META", 14, 45);
        setImage(img);
    }
}
