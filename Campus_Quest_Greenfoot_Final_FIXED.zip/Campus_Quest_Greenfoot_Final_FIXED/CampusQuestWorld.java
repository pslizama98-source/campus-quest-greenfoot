import greenfoot.*;

/** Mundo principal de Campus Quest. */
public class CampusQuestWorld extends World
{
    private Student player;
    private int score = 0;
    private int stress = 0;
    private int lives = 3;
    private int level = 1;
    private int timer = 1600;
    private int spawnCounter = 0;
    private boolean gameOver = false;

    public CampusQuestWorld()
    {
        super(800, 520, 1);
        setPaintOrder(MessageCard.class, GoalPortal.class, Student.class, Coffee.class, Tutor.class, Assignment.class, StressCloud.class);
        prepareLevel();
    }

    public void act()
    {
        if (gameOver) {
            if (Greenfoot.isKeyDown("enter")) {
                Greenfoot.setWorld(new CampusQuestWorld());
            }
            return;
        }

        timer--;
        spawnCounter++;

        if (spawnCounter % 95 == 0) {
            spawnRandomItem();
        }

        if (spawnCounter % 160 == 0) {
            addObject(new StressCloud(level), Greenfoot.getRandomNumber(760) + 20, 0);
        }

        updateHud();

        if (timer <= 0 || lives <= 0 || stress >= 100) {
            finishGame(false);
        }
    }

    private void prepareLevel()
    {
        removeObjects(getObjects(Actor.class));
        drawBackground();
        player = new Student();
        addObject(player, 80, 430);
        addObject(new GoalPortal(), 735, 80);
        addObject(new MessageCard("Campus Quest\nRecolecta entregas, evita el estres y llega al portal.\nFlechas/WASD para moverte."), 400, 72);

        for (int i = 0; i < 5 + level; i++) {
            addObject(new Assignment(), Greenfoot.getRandomNumber(650) + 80, Greenfoot.getRandomNumber(320) + 130);
        }

        for (int i = 0; i < 2; i++) {
            addObject(new Coffee(), Greenfoot.getRandomNumber(650) + 80, Greenfoot.getRandomNumber(320) + 130);
        }

        addObject(new Tutor(), Greenfoot.getRandomNumber(600) + 120, Greenfoot.getRandomNumber(250) + 180);
        updateHud();
    }

    private void drawBackground()
    {
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(35, 49, 80));
        bg.fill();
        bg.setColor(new Color(52, 76, 116));
        bg.fillRect(0, 360, getWidth(), 160);
        bg.setColor(new Color(80, 105, 145));
        bg.fillRect(0, 395, getWidth(), 38);
        bg.setColor(new Color(245, 207, 92));
        bg.fillOval(670, 30, 70, 70);
        bg.setColor(new Color(70, 92, 132));

        for (int x = 40; x < 760; x += 120) {
            bg.fillRect(x, 180, 80, 180);
            bg.setColor(new Color(245, 245, 210));
            bg.fillRect(x + 14, 205, 16, 22);
            bg.fillRect(x + 50, 205, 16, 22);
            bg.fillRect(x + 14, 255, 16, 22);
            bg.fillRect(x + 50, 255, 16, 22);
            bg.setColor(new Color(70, 92, 132));
        }

        bg.setColor(new Color(225, 235, 255));
        bg.drawString("UVG - Campus Quest", 18, 28);
        setBackground(bg);
    }

    private void spawnRandomItem()
    {
        int roll = Greenfoot.getRandomNumber(10);
        int x = Greenfoot.getRandomNumber(700) + 50;
        int y = Greenfoot.getRandomNumber(330) + 135;

        if (roll < 5) {
            addObject(new Assignment(), x, y);
        } else if (roll < 8) {
            addObject(new Coffee(), x, y);
        } else {
            addObject(new Tutor(), x, y);
        }
    }

    public void collectAssignment(Assignment item)
    {
        removeObject(item);
        score += 10;
        stress = Math.max(0, stress - 3);
        playSafe("collect.wav");
    }

    public void collectCoffee(Coffee item)
    {
        removeObject(item);
        score += 5;
        player.boostSpeed();
        playSafe("collect.wav");
    }

    public void collectTutor(Tutor item)
    {
        removeObject(item);
        score += 8;
        stress = Math.max(0, stress - 18);
        playSafe("collect.wav");
    }

    public void hitStress(StressCloud cloud)
    {
        removeObject(cloud);
        lives--;
        stress += 18;
        playSafe("stress.wav");
    }

    public void enterPortal()
    {
        if (score < level * 55) {
            addObject(new MessageCard("Todavia falta avanzar.\nBusca mas entregas antes de salir."), 400, 120);
            return;
        }

        if (level < 3) {
            level++;
            timer += 650;
            stress = Math.max(0, stress - 12);
            playSafe("success.wav");
            prepareLevel();
        } else {
            finishGame(true);
        }
    }

    private void finishGame(boolean won)
    {
        gameOver = true;
        removeObjects(getObjects(Actor.class));
        drawBackground();
        String title = won ? "Mision completada" : "Intento terminado";
        String text = title + "\nPunteo final: " + score + "\nEstres final: " + stress + "%\nPresiona ENTER para jugar de nuevo.";
        addObject(new MessageCard(text), 400, 260);
        if (won) {
            playSafe("success.wav");
        }
    }

    private void updateHud()
    {
        showText("Puntos: " + score, 85, 25);
        showText("Estres: " + stress + "%", 220, 25);
        showText("Vidas: " + lives, 350, 25);
        showText("Nivel: " + level, 465, 25);
        showText("Tiempo: " + (timer / 60), 610, 25);
    }

    private void playSafe(String fileName)
    {
        try {
            Greenfoot.playSound(fileName);
        } catch (Exception e) {
            // El juego sigue funcionando aunque el archivo de sonido no este disponible.
        }
    }
}
