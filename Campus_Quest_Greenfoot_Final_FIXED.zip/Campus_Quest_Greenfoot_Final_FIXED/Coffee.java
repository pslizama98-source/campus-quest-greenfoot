import greenfoot.*;

/** Cafe: da velocidad temporal y algunos puntos. */
public class Coffee extends Actor
{
    public Coffee()
    {
        GreenfootImage img = new GreenfootImage(38, 38);
        img.setColor(new Color(120, 75, 45));
        img.fillOval(7, 9, 22, 22);
        img.setColor(new Color(235, 235, 230));
        img.fillRect(9, 15, 20, 16);
        img.setColor(new Color(80, 45, 25));
        img.drawOval(7, 9, 22, 22);
        img.drawString("+", 16, 28);
        setImage(img);
    }
}
